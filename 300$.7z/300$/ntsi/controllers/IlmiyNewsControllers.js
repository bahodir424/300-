import IlmiyNews from "../models//IlmiyNews.js";

// get all yangiliklar
export const getAllIlmiyNews = async (req, res) => {
  try {
    const titleRegExp = new RegExp(req.query.title, "i");
    const yangiliklar = await IlmiyNews.find({
      title: titleRegExp,
    })
      .skip((req.query.pageNum - 1) * req.query.pageSize)
      .limit(req.query.pageSize);
    res.status(200).json({ data: yangiliklar, total: yangiliklar.length });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// get one yangilik
export const getOneIlmiyNews = async (req, res) => {
  try {
    const id = req.params.id;
    const yangilik = await IlmiyNews.findById(id);
    if (!yangilik) return res.status(404).json({ error: "Not found!" });
    res.status(200).json({ data: yangilik });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// create new yangilik
export const createNewIlmiyNews = async (req, res) => {
  try {
    const { title, description, images } = req.body;
    const newYangiliklar = await IlmiyNews({
      title,
      description,
      images,
    });
    await newYangiliklar.save();
    return res.status(201).json({
      message: "Yangi loyiha yaratildi!",
      data: newYangiliklar,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// update yangilik
export const updateIlmiyNews = async (req, res) => {
  try {
    const updateIlmiyNews = await IlmiyNews.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
      }
    );
    if (!updateIlmiyNews) return res.status(404).json({ error: "Not found!" });
    res.status(200).json({
      message: "Loyiha yangilandi!",
      data: updateIlmiyNews,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// delete yangilik
export const deleteIlmiyNews = async (req, res) => {
  try {
    const deletIlmiyNews = await IlmiyNews.findByIdAndDelete(req.params.id);
    if (!deletIlmiyNews) return res.status(404).json({ error: "Not found!" });
    res.status(200).json({ message: "Loyiha o'chirildi!" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
