import News from "../models/News.js";

// get all yangiliklar
export const getAllNews = async (req, res) => {
  try {
    const titleRegExp = new RegExp(req.query.title, "i");
    const yangiliklar = await News.find({
      title: titleRegExp,
    })
      .skip((req.query.pageNum - 1) * req.query.pageSize)
      .limit(req.query.pageSize);
    res.status(200).json({ data: yangiliklar, total: yangiliklar.length });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// get one yangilik
export const getOneNews = async (req, res) => {
  try {
    const id = req.params.id;
    const yangilik = await News.findById(id);
    if (!yangilik) return res.status(404).json({ error: "Not found!" });
    res.status(200).json({ data: yangilik });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// create new yangilik
export const createNewNews = async (req, res) => {
  try {
    const { title, description, images } = req.body;
    const newYangiliklar = await News({
      title,
      description,
      images,
    });
    await newYangiliklar.save();
    return res.status(201).json({
      message: "Yangi loyiha yaratildi!",
      data: newYangiliklar,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// update yangilik
export const updateNews = async (req, res) => {
  try {
    const updateNews = await News.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!updateNews) return res.status(404).json({ error: "Not found!" });
    res.status(200).json({
      message: "Loyiha yangilandi!",
      data: updateNews,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// delete yangilik
export const deleteNews = async (req, res) => {
  try {
    const deleteProject = await News.findByIdAndDelete(req.params.id);
    if (!deleteProject) return res.status(404).json({ error: "Not found!" });
    res.status(200).json({ message: "Loyiha o'chirildi!" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
