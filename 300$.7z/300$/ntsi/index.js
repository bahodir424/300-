import express from "express";
import dotenv from "dotenv";
import mongoose from "mongoose";

//  Routes
import AdminRoutes from "./routes/AdminRoutes.js";
import NewsRoutes from "./routes/NewsRoutes.js";
import IlmiynewsRoutes from "./routes/IlmiyNewRoutes.js";

//  Needs
import upload from "./config/multer.js";
import cors from "cors";

dotenv.config();

const app = express();

// middleware
app.use(express.json());
app.use(cors());
app.use("/api/uploads", express.static("uploads"));

// routes
app.get("/", (_, res) => {
  res.set("Content-Type", "text/html; charset=UTF-8");
  res.send("Welcome home route!");
});

app.use("/api/admin", AdminRoutes);
app.use("/api/news", NewsRoutes);
app.use("/api/ilmiynews", IlmiynewsRoutes);

// upload new images
app.post("/api/uploads", upload.array("images"), async (req, res) => {
  if (!req.files || req.files.length === 0)
    return res.status(400).json({ error: "No images uploaded!" });
  const uploadedImages = req.files.map(
    (file) =>
      `http://localhost:${process.env.PORT}/api/uploads/${file.filename}`
  );
  res
    .status(200)
    .json({ message: "Successfully uploaded!", images: uploadedImages });
});

const PORT = process.env.PORT || 5000;

mongoose
  .connect(process.env.MONGODB_URI)
  .then(() => app.listen(PORT, () => console.log(`http://localhost:${PORT}`)))
  .catch((error) => console.log("mongodb error: " + error));
