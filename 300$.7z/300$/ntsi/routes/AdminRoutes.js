import express from "express";
import {
  CreateAccount,
  DeleteAccount,
  GetAdminById,
  GetAllAccounts,
  LoginToAccount,
  UpdateAccount,
} from "../controllers/AdminControllers.js";
import { IsExisted } from "../middlewares/isExisted.js";

const router = express.Router();

router.get("/", IsExisted, GetAllAccounts);
router.get("/:id", IsExisted, GetAdminById);
router.post("/login", LoginToAccount);
router.post("/create", IsExisted, CreateAccount);
router.delete("/delete/:id", IsExisted, DeleteAccount);
router.put("/update/:id", IsExisted, UpdateAccount);

export default router;
