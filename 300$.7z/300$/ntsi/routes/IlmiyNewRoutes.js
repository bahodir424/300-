import express from "express";
import {
  createNewIlmiyNews,
  deleteIlmiyNews,
  getAllIlmiyNews,
  getOneIlmiyNews,
  updateIlmiyNews,
} from "../controllers/IlmiyNewsControllers.js";
import { IsExisted } from "../middlewares/isExisted.js";

const router = express.Router();

router.get("/", getAllIlmiyNews);
router.get("/:id", getOneIlmiyNews);
router.post("/create", IsExisted, createNewIlmiyNews);
router.put("/update/:id", IsExisted, updateIlmiyNews);
router.delete("/delete/:id", IsExisted, deleteIlmiyNews);

export default router;
