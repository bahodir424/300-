import express from "express";
import {
  createNewNews,
  getOneNews,
  getAllNews,
  updateNews,
  deleteNews,
} from "../controllers/NewsControllers.js";
import { IsExisted } from "../middlewares/isExisted.js";

const router = express.Router();

router.get("/", getAllNews);
router.get("/:id", getOneNews);
router.post("/create", IsExisted, createNewNews);
router.put("/update/:id", IsExisted, updateNews);
router.delete("/delete/:id", IsExisted, deleteNews);

export default router;
