import React from 'react'
import { NavBar } from '../components/NavBar'
import { Swiperr } from '../components/Swiperr'
import { SectionPart } from '../components/SectionPart'
import { FooterPart } from '../components/FooterPart'

export const Home = () => {
  return (
    <>
        <NavBar />
        <Swiperr />
        <SectionPart />
        <FooterPart />
    </>
  )
}
