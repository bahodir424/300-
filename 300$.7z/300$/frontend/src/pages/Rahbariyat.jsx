import React from "react";

const Rahbariyat = () => {
  return (
    <>
      <section>
        <div className="container">
          
        </div>
      </section>
    </>
  );
};

export default Rahbariyat;
