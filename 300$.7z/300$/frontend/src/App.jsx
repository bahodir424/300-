import React from 'react'
import { RootLayout } from './Layout/RootLayout'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import { Home } from './pages/Home'

const App = () => {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <RootLayout />,
      children: [
        {
          index: true,
          element: <Home />
        }
      ]
    }
  ])
  return (
    <RouterProvider router={router}/>
  )
}

export default App