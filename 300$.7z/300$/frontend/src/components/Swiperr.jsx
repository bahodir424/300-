import React, { useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "./styles.css";
import { Navigation, Pagination } from "swiper/modules";

export const Swiperr = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedSlide, setSelectedSlide] = useState({
    imageClass: "",
    text: "",
  });

  const handleSlideClick = (imageClass, text) => {
    setSelectedSlide({ imageClass, text });
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  return (
    <>
      <Swiper
        slidesPerView={1}
        spaceBetween={30}
        loop={true}
        pagination={{
          clickable: true,
        }}
        navigation={true}
        modules={[Pagination, Navigation]}
        className="mySwiper"
      >
        <SwiperSlide
          onClick={() =>
            handleSlideClick(
              "div",
              "Исҳоқхон Ибрат номидаги мажмуа ҳудудига эътибор қаратилади"
            )
          }
        >
          <div className="div">
            <h1 className="pt-44 text-3xl font-semibold text-white">
              Исҳоқхон Ибрат номидаги мажмуа ҳудудига эътибор қаратилади
            </h1>
          </div>
        </SwiperSlide>
        <SwiperSlide
          onClick={() =>
            handleSlideClick(
              "div1",
              "2016 йилда Президентимиз Шавкат Мирзиёевнинг шахсан ташаббуслари билан Исҳоқхон Ибрат номини абадийлаштириш учун бу маърифатпарвар ҳамюртимизга атаб мажмуа қуришга киришилди ва кўп ўтмай зиёратгоҳ, музей, ижод мактаби ва боғ бунёд этилди."
            )
          }
        >
          <div className="div1">
            <h1 className="pt-44 text-3xl font-semibold text-white">
              2016 йилда Президентимиз Шавкат Мирзиёевнинг шахсан ташаббуслари
              билан Исҳоқхон Ибрат номини абадийлаштириш учун бу маърифатпарвар
              ҳамюртимизга атаб мажмуа қуришга киришилди ва кўп ўтмай зиёратгоҳ,
              музей, ижод мактаби ва боғ бунёд этилди.
            </h1>
          </div>
        </SwiperSlide>
        <SwiperSlide
          onClick={() =>
            handleSlideClick(
              "div2",
              "Ҳозирда бу маскан Тўрақўрғонга келувчилар учун қутлуғ қадамжога айланди. Бироқ, ўтган йиллар, табиат ҳодисалари, фасллар туфайли ҳудуддаги қурилмаларга шикаст етди."
            )
          }
        >
          <div className="div2">
            <h1 className="pt-44 text-3xl font-semibold text-white">
              Ҳозирда бу маскан Тўрақўрғонга келувчилар учун қутлуғ қадамжога
              айланди. Бироқ, ўтган йиллар, табиат ҳодисалари, фасллар туфайли
              ҳудуддаги қурилмаларга шикаст етди.
            </h1>
          </div>
        </SwiperSlide>
        <SwiperSlide
          onClick={() =>
            handleSlideClick(
              "div3",
              "Вилоят ҳокими Шавкатжон Абдураззоқов ҳам кеча бўлиб ўтган сессияда шу ҳақда гапириб, туманнинг янги ҳокимига топшириқлар берди."
            )
          }
        >
          <div className="div3">
            <h1 className="pt-44 text-3xl font-semibold text-white">
              Вилоят ҳокими Шавкатжон Абдураззоқов ҳам кеча бўлиб ўтган сессияда
              шу ҳақда гапириб, туманнинг янги ҳокимига топшириқлар берди.
            </h1>
          </div>
        </SwiperSlide>
        <SwiperSlide
          onClick={() =>
            handleSlideClick(
              "div4",
              "Бугуннинг ўзида туман ҳокими Шерали Қосимов масъуллар билан боғ атрофини кўздан кечирди. Аввало, Косонсой сойи чиқинди ва ўтлардан тозаланади, йўлаклар, зиналар қайта таъмирланади. Манзарали ноёб дарахтлар парвариши кучайтирилади"
            )
          }
        >
          <div className="div4">
            <h1 className="pt-44 text-3xl font-semibold text-white">
              Бугуннинг ўзида туман ҳокими Шерали Қосимов масъуллар билан боғ
              атрофини кўздан кечирди. Аввало, Косонсой сойи чиқинди ва ўтлардан
              тозаланади, йўлаклар, зиналар қайта таъмирланади. Манзарали ноёб
              дарахтлар парвариши кучайтирилади
            </h1>
          </div>
        </SwiperSlide>
      </Swiper>

      {modalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-lg w-full relative">
            <button
              className="absolute top-2 right-2 text-black text-xl font-bold"
              onClick={closeModal}
            >
              &times;
            </button>
            <div
              className={
                selectedSlide.imageClass +
                " h-64 bg-cover bg-center rounded-md mb-4"
              }
            ></div>
            <h1 className="text-2xl font-semibold text-gray-800">
              {selectedSlide.text}
            </h1>
          </div>
        </div>
      )}
    </>
  );
};
