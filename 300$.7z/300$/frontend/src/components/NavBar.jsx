import React, { useState } from "react";
import HoverDropdown from "./HoverDropdown";
import { House } from "@phosphor-icons/react";
import { Link } from "react-router-dom";
import Modal from "./Modal";

export const NavBar = () => {
  const menuItems = [
    [
      "Rahbariyat",
      "Bo‘limlar",
      "Vazifa va funksiyalar",
      "Boshqarma tuzilmi",
      "Odob-ahloq qoidalari",
    ],
    [
      "Malaka oshirish",
      "Namunaviy oʻquv rejalar",
      "Namunaviy oʻquv dasturlari",
      "Buyruqlar",
      "Yigʻilish bayonlari",
      "Chora-tadbirlar rejalari",
    ],
    ["Tadbirlar", "Uchrashuvlar"],
    ["Boʻsh ish oʻrinlari", "Bitiruvchilar bandligi"],
    ["Qabul rejalari", "Kontingent"],
  ];

  const titles = [
    "Texnikum haqida",
    "Meʼyoriy hujjatlar",
    "Maʼnaviy-maʼrifiy ishlar",
    "Bitiruvchi",
    "Qabul - 2024",
  ];

  const [isModalOpen, setIsModalOpen] = useState(false);
  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };
  return (
    <>
      <header>
        <nav>
          <div className="container">
            <div className="flex items-center justify-between">
              <div className="img">
                <img
                  className="w-[100px]"
                  src="https://static5.tgstat.ru/channels/_50/aa/aad49b766dcdea24c7aea7283047e90d.jpg"
                  alt=""
                />
              </div>
              <div className="text">
                <h1 className="w-[500px] text-center font-bold text-3xl">
                  To'raqo'rg'on agrotexnologiyalar texnikumi
                </h1>
              </div>

              <div className="img">
                <img
                  src="https://avatars.mds.yandex.net/i?id=bd39ab7339dc4e3f9522edd8ea5f3c8fbbb0a12b-10604114-images-thumbs&n=13"
                  alt=""
                />
              </div>
            </div>
          </div>
        </nav>
        <nav className="bg-green-600">
          <div className="container flex items-center">
            <House
              size={44}
              className="bg-blue-500 text-white p-2 rounded-md"
            />
            <div className="container flex items-center p-2 gap-2 justify-between">
              <div className="p-2 space-y-4">
                {titles.map((title, index) => (
                  <HoverDropdown
                    key={index}
                    title={title}
                    items={menuItems[index]}
                  />
                ))}
              </div>

              <div className="flex items-center justify-center">
                <button
                  className="pointer bg-blue-500 text-white px-4 py-2 rounded"
                  onClick={toggleModal}
                >
                  <h1 className="text-xl font-medium">Biz bilan aloqa</h1>
                </button>
                <Modal isOpen={isModalOpen} onClose={toggleModal}>
                  <h2 className="text-lg font-bold mb-4">Aloqa</h2>
                  <p>+998 99 999 99 99</p>
                </Modal>
              </div>
            </div>
          </div>
        </nav>
      </header>
    </>
  );
};
