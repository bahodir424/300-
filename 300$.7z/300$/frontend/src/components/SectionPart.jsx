import React from "react";
import "./styles.css";

export const SectionPart = () => {
  return (
    <section className="mt-20 mb-20">
      <div className="a container py-10 px-5">
        <h1 className="uppercase text-xl font-semibold text-gray-500 mb-10">
          Ta'lim yangiliklari
        </h1>
        <div className="news flex flex-col gap-10">
          <div className="new1 flex gap-10">
            <div className="img">
              <img
                src="https://edu.uz/media/2de0b107-9582-1779-0b37-b7ed01fa35bc.jpg"
                className="w-[400px]"
              />
            </div>
            <div className="description flex flex-col justify-between">
              <h3 className="text-xl font-semibold">
                Dual taʼlim istiqbollari muhokama qilindi
              </h3>
              <div className="date-btn flex justify-between items-center">
                <p>28.03.2024</p>
                <button className="bg-blue-500 text-white rounded-md px-5 py-2">
                  Batafsil
                </button>
              </div>
            </div>
          </div>

          <div className="new1 flex gap-10">
            <div className="img">
              <img
                src="https://edu.uz/media/980c180d-4ed1-660d-9dd2-868d246b52a4.jpg"
                className="w-[400px]"
              />
            </div>
            <div className="description flex flex-col justify-between">
              <h3 className="text-xl font-semibold">
                Toshkent davlat texnika universitetida zamonaviy laboratoriya
                foydalanishga topshirildi
              </h3>
              <div className="date-btn flex justify-between items-center">
                <p>28.03.2024</p>
                <button className="bg-blue-500 text-white rounded-md px-5 py-2">
                  Batafsil
                </button>
              </div>
            </div>
          </div>

          <div className="new1 flex gap-10">
            <div className="img">
              <img
                src="https://edu.uz/media/c0288ed0-eae4-2557-5f9d-7718e4e38daa.jpg"
                className="w-[400px]"
              />
            </div>
            <div className="description flex flex-col justify-between">
              <h3 className="text-xl font-semibold">
                Professional ta’lim muassasalari vakillari ta’lim sifatini
                ko‘tarish bo‘yicha o‘zaro tajriba almashdi
              </h3>
              <div className="date-btn flex justify-between items-center">
                <p>28.03.2024</p>
                <button className="bg-blue-500 text-white rounded-md px-5 py-2">
                  Batafsil
                </button>
              </div>
            </div>
          </div>

          <div className="new1 flex gap-10">
            <div className="img">
              <img
                src="https://edu.uz/media/90bf8eae-f86c-ce20-e9d3-7e1045c9dff6.jpg"
                className="w-[400px]"
              />
            </div>
            <div className="description flex flex-col justify-between">
              <h3 className="text-xl font-semibold">
                QORAQALPOG‘ISTON OLIY TAʼLIM MUASSASALARI MATBUOT KOTIBLARI
                UCHUN SEMINAR O‘TKAZILDI
              </h3>
              <div className="date-btn flex justify-between items-center">
                <p>28.03.2024</p>
                <button className="bg-blue-500 text-white rounded-md px-5 py-2">
                  Batafsil
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
