import {
  FacebookLogo,
  InstagramLogo,
  TelegramLogo,
  YoutubeLogo,
} from "@phosphor-icons/react";
import React from "react";
import { Link } from "react-router-dom";

export const FooterPart = () => {
  return (
    <footer className="bg-blue-600 text-white py-8">
      <div className="container mx-auto flex gap-10 items-center">
        <div>
          <div className="divv items-center flex gap-5">
            <img
              src="https://edu.uz/media/37e379c0-6158-b6a0-5ee7-5a0a2aa46860.png"
              alt="Logo"
              className="mb-4 w-[100px]"
            />
            <h2 className="text-xl font-bold mb-4">
              To'raqo'rg'on agrotexnologiyalar texnikumi
            </h2>
          </div>
          <ul className="space-y-2">
            <li>
              <span className="inline-block w-6 mr-2">📍</span>
              Manzil: 100174, Toshkent sh., Olmazor tumani, Universitet
              ko‘chasi, 7-uy
            </li>
            <li>
              <span className="inline-block w-6 mr-2">📞</span>
              Ishonch telefoni: 1006
            </li>
            <li>
              <span className="inline-block w-6 mr-2">☎️</span>
              Murojaatlar bilan ishlash bo‘limi: 55-520-08-08 (198, 199, 200,
              201)
            </li>
            <li>
              <span className="inline-block w-6 mr-2">📠</span>
              Devonxona: 55-520-08-08 (195)
            </li>
            <li>
              <span className="inline-block w-6 mr-2">✉️</span>
              E-mail: edu@exat.uz | devxonxona@edu.uz
            </li>
            <li>
              <span className="inline-block w-6 mr-2">🗺️</span>
              Geolokatsiya
            </li>
          </ul>
        </div>
        <div>
          <h2 className="text-xl font-bold mb-4">Foydali havolalar</h2>
          <ul className="space-y-2">
            <li>Sayt xaritasi</li>
            <li>
              Veb-sayt foydalanuvchilarining shaxsiy ma’lumotlarini himoya
              qilish siyosati haqida ma’lumot
            </li>
            <li>
              Veb saytdan foydalanish bo‘yicha qo‘llanma va tuzilmaviy mazmuni
            </li>
            <li>Davlat ramzlari</li>
            <li>Zilzila bo‘lganda nima qilish kerak?</li>
            <li>Qayta aloqa</li>
            <li>Ishonch telefoni</li>
          </ul>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-4">Ijtimoiy tarmoqlar</h2>
          <div className="flex space-x-4 mb-4">
            <Link className="text-2xl">
              <FacebookLogo />
            </Link>
            <Link className="text-2xl">
              <InstagramLogo />
            </Link>
            <Link className="text-2xl">
              <TelegramLogo />
            </Link>
            <Link className="text-2xl">
              <YoutubeLogo />
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
