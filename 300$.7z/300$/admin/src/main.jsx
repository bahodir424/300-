import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import { configureStore } from "@reduxjs/toolkit";
import UserReducer from "./Toolkit/UserSlicer.jsx";
import { Provider } from "react-redux";
import OrdersReducer from "./Toolkit/OrdersSlicer.jsx";
import AdminSlicer from "./Toolkit/AdminSlicer.jsx";

const store = configureStore({
  reducer: {
    user: UserReducer,
    admins: AdminSlicer,
    orders: OrdersReducer,
  },
});

ReactDOM.createRoot(document.getElementById("root")).render(
  <Provider store={store}>
    <App />
  </Provider>
);
