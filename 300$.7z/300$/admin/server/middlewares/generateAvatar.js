export default function (firstName, lastName) {
  return `https://avatar.iran.liara.run/username?username=${lastName}+${firstName}`;
}